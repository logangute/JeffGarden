/**
 * Created by zhengjiabin on 6/29/16.
 */


function getSitePoint() {
    return window.location.origin + '/Jeff'
}