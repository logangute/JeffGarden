package cn.jiang.garden.enums;

import java.io.Serializable;

/**
 * Created by TIANCHENGYUAN103 on 2015-12-04.
 */
public enum CallStatusEnum implements Serializable {
    SUCCEED,
    FAILED,;

    CallStatusEnum() {
    }
}